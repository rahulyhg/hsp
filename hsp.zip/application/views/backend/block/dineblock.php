<section class="panel">

    <div class="panel-body">
        <ul class="nav nav-stacked">
            <li><a href="<?php echo site_url('site/editdine?id=').$before->id; ?>">Dine Details</a></li>
<!--            <li><a href="<?php echo site_url('site/viewdinecategory?id=').$before->id; ?>">Dine Category</a></li>-->
            <li><a href="<?php echo site_url('site/viewdinedeal?id=').$before->id; ?>">Dine Deals</a></li>
        </ul>
    </div>
</section>