<section class="panel">

    <div class="panel-body">
        <ul class="nav nav-stacked">
            <li><a href="<?php echo site_url('site/editbrand?id=').$before->id; ?>">Brand Details</a></li>
<!--            <li><a href="<?php echo site_url('site/viewbrandcategory?id=').$before->id; ?>">Brand Category</a></li>-->
            <li><a href="<?php echo site_url('site/viewbranddeal?id=').$before->id; ?>">Brand Deals</a></li>
        </ul>
    </div>
</section>