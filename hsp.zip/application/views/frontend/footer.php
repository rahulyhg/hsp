<footer>
  <ul class="social clearfix alignleft">
    <li ><a href="contact.php">CONTACT</a></li>
    <li ><a href="about_us.php">ABOUT</a></li>
      <li ><a href="press.php">PRESS</a></li>
      <li ><a href="#">CONCIERGE SERVICES</a></li>
      <li ><a href="jobs.php">JOBS</a></li>
      <li ><a href="#">GIFT CARDS</a></li>
  </ul>
 <ul class="copyright clearfix alignleft">
      <li><a href="#"><img src="<?php echo base_url("frontend")."/";?>images/inst_b.png" /></a> </li>
      <li><a href="#"><img src="<?php echo base_url("frontend")."/";?>images/youtube_b.png" /></a> </li>
      <li><a href="#"><img src="<?php echo base_url("frontend")."/";?>images/pinintrest_b.png" /></a> </li>
      <li><a href="https://twitter.com/gophoenixing?original_referer=http%3A%2F%2Fhighstreetphoenix.com%2F&profile_id=134720718&tw_i=552721616396750848&tw_p=embeddedtimeline&tw_w=351643332365139968" target="_blank"><img src="<?php echo base_url("frontend")."/";?>images/twitter_b.png" /></a> </li>
      <li><a href="https://www.facebook.com/highstreetphoenix" target="_blank"><img src="<?php echo base_url("frontend")."/";?>images/facebook_b.png" /></a> </li>
  </ul>
</footer>
<div id="backtotop">
  <ul>
    <li><a id="toTop" href="#" onClick="return false">Back to Top</a></li>
  </ul>
</div>